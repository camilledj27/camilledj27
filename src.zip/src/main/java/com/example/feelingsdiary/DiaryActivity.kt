package com.example.feelingsdiary

import androidx.appcompat.app.AppCompatActivity

class DiaryActivity : AppCompatActivity() {


}